from django.apps import AppConfig


class EdiaryConfig(AppConfig):
    name = 'eDiary'
